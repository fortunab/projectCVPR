"""Run source-only selection and leave-one-center-out CBMP experiments."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import joblib
import torch
from PIL import Image
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, roc_auc_score
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

from cbmp import (CosineHead, PrototypeModel, fit_cosine_head, fit_prototypes,
                  select_hyperparameters, select_temperature_folds)
from cbmp_data import MANIFEST_SCHEMA_VERSION, build_manifest, load_manifest, make_outer_splits
from foundation_models import create_foundation_model
from polyp_dataset import get_endoscopy_transforms


class ManifestImages(Dataset):
    def __init__(self, rows, transform):
        self.rows = rows
        self.transform = transform

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        row = self.rows[index]
        with Image.open(row["image_path"]) as image:
            image = image.convert("RGB")
        return self.transform(image), index


def _manifest_digest(rows):
    columns = ("sample_id", "sha256", "center", "group_id", "label", "label_source", "mask_sha256", "bbox_sha256")
    payload = json.dumps([{key: row[key] for key in columns} for row in rows], sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()


def extract_features(rows, model_name, batch_size, workers, device, cache_path, force=False):
    digest = _manifest_digest(rows)
    cache_path = Path(cache_path)
    if cache_path.exists() and not force:
        cached = np.load(cache_path, allow_pickle=False)
        if str(cached["manifest_digest"].item()) != digest or str(cached["model_name"].item()) != model_name:
            raise ValueError("Feature cache does not match this manifest/model; choose another cache or --force-features")
        resolved_model = str(cached["resolved_model"].item())
        if model_name.startswith("dinov2") and "dinov2" not in resolved_model.lower():
            raise RuntimeError(f"Cached encoder {resolved_model} is not the requested DINOv2 model")
        return cached["features"], resolved_model

    encoder, cfg = create_foundation_model(model_name=model_name)
    resolved_model = str(cfg["model_name"])
    if model_name.startswith("dinov2") and "dinov2" not in resolved_model.lower():
        raise RuntimeError(
            f"Requested {model_name}, but the factory resolved {resolved_model}; refusing a silent architecture fallback"
        )
    encoder.to(device).eval()
    transform = get_endoscopy_transforms(
        img_size=cfg["img_size"], is_training=False, mean=cfg["mean"], std=cfg["std"]
    )
    loader = DataLoader(
        ManifestImages(rows, transform), batch_size=batch_size, shuffle=False,
        num_workers=workers, pin_memory=str(device).startswith("cuda")
    )
    features = None
    with torch.inference_mode():
        for images, positions in tqdm(loader, desc=f"Extract {model_name}"):
            output = encoder(images.to(device, non_blocking=True))
            output = output.float().cpu().numpy()
            if features is None:
                features = np.zeros((len(rows), output.shape[1]), dtype=np.float32)
            features[positions.numpy()] = output
    if features is None or not np.isfinite(features).all():
        raise ValueError("Encoder returned no or non-finite features")
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(cache_path, features=features, manifest_digest=digest,
                        model_name=model_name, resolved_model=resolved_model)
    return features, resolved_model


def _logistic_select(features, labels, folds, n_classes, seed):
    candidates = [0.01, 0.1, 1.0, 10.0, 100.0]
    results = []
    for c_value in candidates:
        scores = []
        for train_idx, val_idx in folds:
            model = LogisticRegression(C=c_value, max_iter=3000, class_weight="balanced", random_state=seed)
            model.fit(features[train_idx], labels[train_idx])
            scores.append(balanced_accuracy_score(labels[val_idx], model.predict(features[val_idx])))
        results.append((float(np.mean(scores)), -c_value, c_value))
    return max(results)[2]


def _fit_cosine_with_source_temperature(features, labels, inner, n_classes, seed):
    score_folds, label_folds = [], []
    for inner_id, (inner_train, inner_val) in enumerate(inner):
        head = fit_cosine_head(features[inner_train], labels[inner_train], n_classes,
                               seed=seed + inner_id)
        score_folds.append(head.scores(features[inner_val]))
        label_folds.append(labels[inner_val])
    tau = select_temperature_folds(score_folds, label_folds)
    return tau


def _metrics(labels, predictions, probabilities):
    result = {
        "accuracy": float(accuracy_score(labels, predictions)),
        "balanced_accuracy": float(balanced_accuracy_score(labels, predictions)),
        "macro_f1": float(f1_score(labels, predictions, average="macro", zero_division=0)),
    }
    if len(np.unique(labels)) == 2:
        result["auroc"] = float(roc_auc_score(labels, probabilities[:, 1]))
    else:
        result["auroc"] = float(roc_auc_score(labels, probabilities, multi_class="ovr", average="macro"))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, default=Path("results/cbmp/manifest.csv"))
    parser.add_argument("--results-dir", type=Path, default=Path("results/cbmp"))
    parser.add_argument("--feature-cache", type=Path, default=Path("cache/cbmp_features.npz"))
    parser.add_argument("--model-name", default="dinov2_base")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=17)
    parser.add_argument("--device", default="auto", choices=("auto", "cpu", "cuda"))
    parser.add_argument("--force-features", action="store_true")
    parser.add_argument("--sequence-metadata", type=Path, help="Reviewed sequence-to-center metadata CSV")
    parser.add_argument("--sequence-only", action="store_true", help="Exclude stills without video grouping")
    parser.add_argument("--allow-image-only-groups", action="store_true",
                        help="Proceed without patient/sequence IDs (not valid for leakage-controlled video evaluation)")
    args = parser.parse_args()

    device = "cuda" if args.device == "auto" and torch.cuda.is_available() else args.device
    if device == "auto":
        device = "cpu"
    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    args.results_dir.mkdir(parents=True, exist_ok=True)

    if args.manifest.exists():
        audit_path = args.manifest.with_suffix(".audit.json")
        if not audit_path.exists():
            raise FileNotFoundError(f"Missing {audit_path}; run audit_cbmp_data.py and review its output first")
        audit = json.loads(audit_path.read_text(encoding="utf-8"))
        if audit.get("schema_version") != MANIFEST_SCHEMA_VERSION:
            raise ValueError("Legacy manifest uses unsafe path-based labels; rebuild with audit_cbmp_data.py")
        if Path(audit["data_root"]).resolve() != args.data_root.expanduser().resolve():
            raise ValueError("Manifest audit data root does not match --data-root")
        if args.sequence_metadata and audit.get("sequence_metadata") != str(args.sequence_metadata.resolve()):
            raise ValueError("Existing manifest used different sequence metadata; rebuild it with audit_cbmp_data.py")
        rows = load_manifest(args.manifest)
        print(f"Using existing manifest: {args.manifest}")
    else:
        audit = build_manifest(args.data_root, args.manifest, sequence_metadata=args.sequence_metadata,
                               sequence_only=args.sequence_only)
        rows = load_manifest(args.manifest)
        print(json.dumps(audit, indent=2))
    if audit.get("blocking_rejections", 0):
        raise ValueError("Unresolved centers or annotation errors remain; inspect the rejected CSV and rebuild the audit")
    if args.sequence_only and not audit.get("sequence_only"):
        raise ValueError("Existing manifest includes stills; rebuild it with --sequence-only")
    labels = np.asarray([r["label"] for r in rows], dtype=np.int64)
    centers = np.asarray([r["center"] for r in rows], dtype=str)
    groups = np.asarray([r["group_id"] for r in rows], dtype=str)
    classes = np.unique(labels)
    if not np.array_equal(classes, np.arange(len(classes))):
        raise ValueError(f"Labels must be contiguous integers from 0; found {classes.tolist()}")
    if len(classes) != 2:
        raise ValueError(f"This experiment currently implements binary polyp classification; found {classes.tolist()}")
    image_only = sum(r["group_source"] == "image_only_no_sequence_id" for r in rows)
    if image_only and not args.allow_image_only_groups:
        raise ValueError(
            f"{image_only}/{len(rows)} rows lack sequence/patient group metadata. "
            "Recover group IDs in the manifest before evaluation, or explicitly opt in with "
            "--allow-image-only-groups for a diagnostic pilot only."
        )

    splits = make_outer_splits(rows, seed=args.seed)
    if not any(split["status"] == "ready" for split in splits):
        statuses = {split["heldout_center"]: split["status"] for split in splits}
        raise RuntimeError(f"No valid center-held-out folds; inspect class coverage and duplicate content: {statuses}")

    feature_cache = args.feature_cache
    if not feature_cache.is_absolute():
        feature_cache = args.results_dir / feature_cache
    features, resolved_model = extract_features(rows, args.model_name, args.batch_size, args.workers, device,
                                                feature_cache, force=args.force_features)
    split_path = args.results_dir / "outer_splits.json"
    split_path.write_text(json.dumps({"manifest_digest": _manifest_digest(rows), "splits": splits}, indent=2), encoding="utf-8")
    (args.results_dir / "experiment_config.json").write_text(json.dumps({
        "seed": args.seed, "requested_model": args.model_name, "resolved_model": resolved_model,
        "device": str(device), "batch_size": args.batch_size, "manifest_digest": _manifest_digest(rows),
        "n_samples": len(rows), "n_classes": len(classes), "centers": sorted(set(centers)),
        "k_grid": [1, 2, 4, 8], "beta_grid": [0.0, 0.5, 1.0],
        "temperature_grid_search": "bounded scalar NLL optimization on source-only validation predictions"
    }, indent=2), encoding="utf-8")

    fold_records, prediction_rows = [], []
    for outer in splits:
        if outer["status"] != "ready":
            print(f"[SKIP] {outer['heldout_center']}: {outer['status']}")
            continue
        train_idx = np.asarray(outer["outer_train"], dtype=np.int64)
        test_idx = np.asarray(outer["outer_test"], dtype=np.int64)
        inner = [(np.asarray(f["train"], dtype=np.int64), np.asarray(f["validation"], dtype=np.int64)) for f in outer["inner_folds"]]
        k, beta = select_hyperparameters(features, labels, centers, groups, inner, len(classes), seed=args.seed)

        val_scores, val_labels = [], []
        for inner_id, (inner_train, inner_val) in enumerate(inner):
            model = fit_prototypes(features[inner_train], labels[inner_train], centers[inner_train], groups[inner_train],
                                   len(classes), k=k, beta=beta, seed=args.seed + inner_id)
            val_scores.append(model.scores(features[inner_val]))
            val_labels.append(labels[inner_val])
        temperature = select_temperature_folds(val_scores, val_labels)

        methods = {}
        proposed = fit_prototypes(features[train_idx], labels[train_idx], centers[train_idx], groups[train_idx],
                                  len(classes), k=k, beta=beta, seed=args.seed)
        methods["cbmp"] = PrototypeModel(proposed.prototypes, proposed.valid, temperature)
        cosine_tau = _fit_cosine_with_source_temperature(features, labels, inner, len(classes), args.seed)
        cosine_head = fit_cosine_head(features[train_idx], labels[train_idx], len(classes), seed=args.seed)
        methods["trainable_cosine"] = CosineHead(cosine_head.weights, cosine_tau)
        for baseline_beta, name in ((0.0, "single_centroid_group_weighted"), (1.0, "single_centroid_center_balanced")):
            methods[name] = fit_prototypes(features[train_idx], labels[train_idx], centers[train_idx], groups[train_idx],
                                           len(classes), k=1, beta=baseline_beta, seed=args.seed)
        image_groups = np.asarray([f"image:{i}" for i in train_idx], dtype=str)
        methods["single_centroid_image_weighted"] = fit_prototypes(
            features[train_idx], labels[train_idx], centers[train_idx], image_groups,
            len(classes), k=1, beta=0.0, seed=args.seed
        )
        methods["multi_prototype_unbalanced"] = fit_prototypes(
            features[train_idx], labels[train_idx], centers[train_idx], groups[train_idx],
            len(classes), k=k, beta=0.0, seed=args.seed
        )
        c_value = _logistic_select(features, labels, inner, len(classes), args.seed)
        logistic = LogisticRegression(C=c_value, max_iter=3000, class_weight="balanced", random_state=args.seed)
        logistic.fit(features[train_idx], labels[train_idx])
        model_dir = args.results_dir / "models" / outer["heldout_center"]
        model_dir.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(model_dir / "cbmp.npz", prototypes=methods["cbmp"].prototypes,
                            valid=methods["cbmp"].valid, temperature=temperature,
                            k=k, beta=beta, seed=args.seed)
        np.savez_compressed(model_dir / "trainable_cosine.npz", weights=cosine_head.weights,
                            temperature=cosine_tau, seed=args.seed)
        joblib.dump(logistic, model_dir / "linear_logistic.joblib")

        for method_name, model in methods.items():
            pred = model.predict(features[test_idx])
            proba = model.probabilities(features[test_idx])
            metrics = _metrics(labels[test_idx], pred, proba)
            fold_records.append({"heldout_center": outer["heldout_center"], "method": method_name,
                                 "k": k if method_name in ("cbmp", "multi_prototype_unbalanced") else 1,
                                 "beta": beta if method_name == "cbmp" else (0.0 if method_name != "single_centroid_center_balanced" else 1.0),
                                 "temperature": model.temperature, "metrics": metrics})
            for local, idx in enumerate(test_idx):
                prediction_rows.append({"sample_id": rows[idx]["sample_id"], "center": rows[idx]["center"],
                                        "group_id": rows[idx]["group_id"], "label": int(labels[idx]),
                                        "method": method_name, "prediction": int(pred[local]),
                                        "probability_class_1": float(proba[local, 1])})

        pred = logistic.predict(features[test_idx])
        proba = logistic.predict_proba(features[test_idx])
        metrics = _metrics(labels[test_idx], pred, proba)
        fold_records.append({"heldout_center": outer["heldout_center"], "method": "linear_logistic",
                             "k": None, "beta": None, "temperature": None, "C": c_value, "metrics": metrics})
        for local, idx in enumerate(test_idx):
            prediction_rows.append({"sample_id": rows[idx]["sample_id"], "center": rows[idx]["center"],
                                    "group_id": rows[idx]["group_id"], "label": int(labels[idx]),
                                    "method": "linear_logistic", "prediction": int(pred[local]),
                                    "probability_class_1": float(proba[local, 1])})
        print(f"[DONE] held-out={outer['heldout_center']} selected K={k}, beta={beta:.2f}, tau={temperature:.3f}")

    if not fold_records:
        raise RuntimeError("No valid outer center folds. Review the audit and split exclusions before training.")
    (args.results_dir / "metrics_by_center.json").write_text(json.dumps(fold_records, indent=2), encoding="utf-8")
    with (args.results_dir / "predictions.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(prediction_rows[0]))
        writer.writeheader()
        writer.writerows(prediction_rows)
    print(f"Saved metrics, splits, and predictions to {args.results_dir.resolve()}")


if __name__ == "__main__":
    main()

